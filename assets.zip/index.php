﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <meta name="description" content="Turismo">
    <meta name="B-verify" content="c997d52d852c6e8fe711749d8e66d854247d1bee" /> 
    <meta name="keywords" content="RECREO">
    <title>El Recreo es de Todos</title>
    <link rel="shortcut icon" href="/imagenes/icono.ico"> 
    <link rel="icon" type="image/gif" href="/imagenes/animated_favicon1.gif">
</HEAD>
</html>